
public class DeckExhaustedException extends Exception{

}
