
/**
 * <p>A Card in an Uno deck. Each Card knows its particular type, which is
 * comprised of a 3-tuple (color, rank, number). Not all of these values
 * are relevant for every particular type of card, however; for instance,
 * wild cards have no color (getColor() will return Color.NONE) or number
 * (getNumber() will return -1).</p>
 * <p>A Card knows its forfeit cost (<i>i.e.</i>, how many points it counts
 * against a loser who gets stuck with it) and how it should act during
 * game play (whether it permits the player to change the color, what
 * effect it has on the game state, etc.)</p>
 * @since 1.0
 */
public class Card {


    public static final boolean PRINT_IN_COLOR = false;
    private Color color;
    private Rank rank;
    private int number;

    /**
     * Constructor for non-number cards (skips, wilds, etc.)
     */
    public Card(Color color, Rank rank) {
        this.color = color;
        this.rank = rank;
        this.number = -1;
    }

    /**
     * Constructor for number cards.
     */
    public Card(Color color, int number) {
        this.color = color;
        this.rank = Rank.NUMBER;
        this.number = number;
    }

    /**
     * Constructor to explicitly set entire card state.
     */
    public Card(Color color, Rank rank, int number) {
        this.color = color;
        this.rank = rank;
        this.number = number;
    }

    /**
     * Render this Card object as a string. Whether the string comes out
     * with ANSI color codes is controlled by the PRINT_IN_COLOR static
     * class variable.
     */
    public String toString() {
        String cards = "";
        if (PRINT_IN_COLOR) {
            switch (getColor()) {
                case RED:
                    cards += "\033[31m";
                    break;
                case YELLOW:
                    cards += "\033[33m";
                    break;
                case GREEN:
                    cards += "\033[32m";
                    break;
                case BLUE:
                    cards += "\033[34m";
                    break;
                case NONE:
                    cards += "\033[1m";
                    break;
            }
        }
        else {
            switch (getColor()) {
                case RED:
                    cards += "R";
                    break;
                case YELLOW:
                    cards += "Y";
                    break;
                case GREEN:
                    cards += "G";
                    break;
                case BLUE:
                    cards += "B";
                    break;
                case NONE:
                    cards += "";
                    break;
            }
        }
        switch (getRank()) {
            case NUMBER:
                cards += number;
                break;
            case SKIP:
                cards += "S";
                break;
            case REVERSE:
                cards += "R";
                break;
            case WILD:
                cards += "W";
                break;
            case DRAW_TWO:
                cards += "+2";
                break;
            case WILD_D4:
                cards += "W4";
                break;
        }
        if (PRINT_IN_COLOR) {
            cards += "\033[37m\033[0m";
        }
        return cards;
    }

    /**
     * Returns the number of points this card will count against a player
     * who holds it in his/her hand when another player goes out.
     */
    public int forfeitCost() {
        if (rank == Rank.SKIP || rank == Rank.REVERSE ||
            rank == Rank.DRAW_TWO) {
            return 20;
        }
        if (rank == Rank.WILD || rank == Rank.WILD_D4) {
            return 50;
        }
        if (rank == Rank.NUMBER) {
            return number;
        }
        System.out.println("Illegal card!");
        return -10000;
    }

    /**
     * Returns true only if this Card can legally be played on the up card
     * passed as an argument. The second argument is relevant only if the
     * up card is a wild.
     * @param upCard An "up card" upon which the current object might (or might
     * not) be a legal play.
     * @param calledColor If the up card is a wild card, this parameter
     * contains the color the player of that color called.
     */ 
    public boolean canPlayOn(Card upCard, Color calledColor) {
        if ((upCard.rank == Rank.WILD || upCard.rank  == Rank.WILD_D4) && calledColor == getColor() ) {
        	return true;
        }
        if (getRank()  == Rank.WILD || getRank() == Rank.WILD_D4) {
        	return true;
        }
               
        if (upCard.color == getColor()) {
        	return true;
        }
        if(upCard.rank == getRank() && upCard.color == getColor() ) {
        	return true;
        }
        if ((upCard.rank == Rank.REVERSE && getRank() == Rank.REVERSE) || (upCard.rank == Rank.SKIP && getRank() == Rank.SKIP)) {
        	return true;
        }
        if(upCard.rank == Rank.NUMBER && upCard.number == getNumber() ) {
        	return true;
        }
        return false;
}
    

    /**
     * Returns true only if playing this Card object would result in the
     * playernumber being asked for a color to call. (In the standard game, this
     * is true only for wild cards.)
     */
    public boolean isWildCard() {
        return getRank() == Rank.WILD || getRank() == Rank.WILD_D4;
    }

    /**
     * Returns the color of this card, which is Color.NONE in the case of
     * wild cards.
     */
    public Color getColor() {
        return color;
    }

    /**
     * Returns the rank of this card, which is Rank.NUMBER in the case of
     * number cards (calling getNumber() will retrieve the specific
     * number.)
     */
    public Rank getRank() {
        return rank;
    }

    /**
     * Returns the number of this card, which is guaranteed to be -1 for
     * non-number cards (cards of non-Rank.NUMBER rank.)
     */
    public int getNumber() {
        return number;
    }
    
}
    
    

