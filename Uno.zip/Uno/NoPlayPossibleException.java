
public class NoPlayPossibleException extends Exception{

}
